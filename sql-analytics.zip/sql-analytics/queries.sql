use db_magasin;

SELECT * FROM clients;
SELECT * FROM produits;
SELECT * FROM ventes;

/**
1. Le Chiffre d'Affaires "Tennis Premium"

"Je veux savoir ce que nous rapporte r�ellement le Tennis. Peux-tu me donner le Chiffre 
d'Affaires total (somme des ventes) uniquement pour la cat�gorie 'Tennis' ?" **/

SELECT SUM(prix_unitaire * quantite) AS chiffre_affaire_total_cat_Tennis 
FROM ventes 
WHERE categorie_produit = 'Tennis';


/***
 2. L'analyse "Stock Rando"

 "On parle beaucoup de la Rando � Goma. Donne-moi le nombre total d'articles
 en stock dont le nom contient 'Rando'. Je veux un seul chiffre global."


***/
SELECT SUM(stock) As nombre_total_article_stock_Rando
FROM produits
WHERE nom_produit LIKE '%Rando%';




/*** 
3. Le dynamisme des "Villes Prioritaires"

"On a investi � Bukavu et Matadi. Combien de clients avons-nous dans chacune de ces deux villes ?
Affiche le nom de la ville et le nombre d'inscrits."
***/

SELECT COUNT(id_client) AS nombre_clients_inscrits, ville
FROM clients 
WHERE ville IN ('Bukavu', 'Matadi')
GROUP BY ville;


/***
4.  Le panier moyen "Combat"

"Pour les articles de sport de combat dont le prix est entre 20$ et 50$, quel est le prix moyen de ces articles ?"
**/

SELECT AVG(prix) AS prix_moyen_article
FROM produits
WHERE categorie = 'Combat'
AND  prix BETWEEN 20 AND 50;


/****
5.La performance "Lubumbashi"

"Derni�re chose : pour nos clients de Lubumbashi inscrits avant 2025, 
quel est le nombre total de transactions (ventes) qu'ils ont g�n�r�es ?"

**/
SELECT COUNT(id_vente) As nombre_total_transactions
FROM ventes 
WHERE ville_client = 'Lubumbashi'
AND YEAR(date_inscription_client) < 2025;


SELECT COUNT(id_vente) As nombre_total_transactions
FROM ventes 
WHERE ville_client = 'Lubumbashi'
AND date_inscription_client < '2025-01-01';



/**
6. le chiffre d'affaires total par cat�gorie de produits du magasin
**/

SELECT SUM(prix_unitaire * quantite) As chiffres_affaires_total, categorie_produit 
FROM ventes 
GROUP BY categorie_produit;
